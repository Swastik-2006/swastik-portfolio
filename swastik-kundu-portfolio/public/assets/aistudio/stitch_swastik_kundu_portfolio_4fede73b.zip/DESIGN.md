---
name: Neo-Digital Editorial
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393f'
  surface-container-lowest: '#0c0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e2025'
  surface-container-high: '#282a2f'
  surface-container-highest: '#33353a'
  on-surface: '#e2e2e9'
  on-surface-variant: '#c4c9b2'
  inverse-surface: '#e2e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#8e937e'
  outline-variant: '#444938'
  surface-tint: '#add450'
  primary: '#ffffff'
  on-primary: '#263500'
  primary-container: '#c8f169'
  on-primary-container: '#516d00'
  inverse-primary: '#4d6700'
  secondary: '#c2c1ff'
  on-secondary: '#1c09a0'
  secondary-container: '#3630b5'
  on-secondary-container: '#aeadff'
  tertiary: '#ffffff'
  on-tertiary: '#2e3038'
  tertiary-container: '#e1e2ec'
  on-tertiary-container: '#62646c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c8f169'
  primary-fixed-dim: '#add450'
  on-primary-fixed: '#151f00'
  on-primary-fixed-variant: '#394d00'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c2c1ff'
  on-secondary-fixed: '#0d006a'
  on-secondary-fixed-variant: '#3630b5'
  tertiary-fixed: '#e1e2ec'
  tertiary-fixed-dim: '#c4c6cf'
  on-tertiary-fixed: '#191c22'
  on-tertiary-fixed-variant: '#44474e'
  background: '#111318'
  on-background: '#e2e2e9'
  surface-variant: '#33353a'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 76px
    letterSpacing: -0.04em
  display-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  code-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

The visual identity channels the aura of an avant-garde AI engineer and technical explorer: disciplined engineering rigor paired with hyper-modern digital expression. It avoids sterile corporate patterns in favor of Gen-Z neo-minimalism—blending high-fashion editorial cadence with technical precision. 

The aesthetic is constructed on tactile dark space, razor-sharp typography hierarchies, micro-glows, and utilitarian technical accents. It should evoke curiosity, computational authority, and creative speed. The interface balances high-contrast typographic moments with calm, structured negative space.

## Colors

- **Canvas & Surfaces:**
  - Base canvas: `#111318` (Ink Black)
  - Elevated card surface: `#181B22`
  - Subtle overlays and interaction states: `rgba(245, 244, 239, 0.04)`
- **Typography:**
  - Primary text and critical headlines: `#F5F4EF` (Soft Ivory)
  - Secondary body, metadata, and passive states: `#92949D` (Muted Grey)
- **Accents & Interactions:**
  - Primary interactive anchor: `#C8F169` (Acid Lime). Used for primary calls-to-action, key badges, terminal prompts, and active focal points.
  - Secondary interactive accent: `#7775F7` (Electric Violet). Used for technical taglines, dynamic focus rings, and code syntax highlights.
  - Borders and dividers: `rgba(146, 148, 157, 0.18)` hairline definitions.

## Typography

The type scale juxtaposes raw structural display fonts with an exceptionally neutral reading workhorse. `Space Grotesk` governs all macro-scale display copy, section headers, metadata labels, and metrics, bringing a distinct technical personality and kinetic weight. `Inter` provides high-density readability for case studies, logs, and project breakdowns.

Editorial headlines (`display-xl`) utilize negative tracking to create a compressed, sculptural aesthetic. Metadata tags and labels are tracked wide and rendered uppercase for an intentional engineering-schematic posture.

## Layout & Spacing

A 12-column responsive fluid grid governs desktop displays (max-width `1280px`), adapting to an 8-column layout on tablet and a 4-column layout on mobile devices. 

Layout rhythm alternates between tight, technical micro-spacing inside interactive units (`space-xs` to `space-sm`) and expansive macro-whitespace separating content blocks (`space-xl` to `space-2xl`). Asymmetrical layout shifts are encouraged—such as offset column spans for project showcases—to enforce editorial dynamism rather than standard dashboard modularity.

## Elevation & Depth

Depth is established primarily through tonal layering, dark glassmorphism, and hairline illumination rather than heavy blur shadows:

- **Surface Tiers:** Baseline canvas sits at `#111318`. Interactive panels sit at `#181B22` with a 1px border of `rgba(146, 148, 157, 0.18)`.
- **Frosted Elements:** Navigation headers and sticky overlays utilize `backdrop-filter: blur(12px)` over `rgba(17, 19, 24, 0.75)`.
- **Glow Accents:** Elevated elements interactively project tight ambient micro-glows: `box-shadow: 0 0 24px -4px rgba(200, 241, 105, 0.15)` for Acid Lime accents and `box-shadow: 0 0 24px -4px rgba(119, 117, 247, 0.18)` for Electric Violet elements.
- **Hairlines:** Thin 1px outer borders define edges cleanly, avoiding muddiness on dark panels.

## Shapes

The interface embraces a structured, near-monolithic geometry. A subtle 4px (`roundedness: 1`) baseline curve softens component perimeters without sacrificing technical sharpness. Outer containment panels use 8px (`rounded-lg`), while inner pills and utility badges utilize complete circle or capsule rounding (9999px) to contrast with the rectangular foundations.

## Components

- **Buttons:**
  - *Primary:* Solid `#C8F169` fill with `#111318` Space Grotesk bold text. Sharp hover transition with subtle scale (`1.02`) and Acid Lime glow.
  - *Secondary / Ghost:* Hairline border `rgba(146, 148, 157, 0.28)` on transparent surface, `#F5F4EF` text. Hover shifts border color to `#7775F7` with subtle background tint `rgba(119, 117, 247, 0.08)`.
- **Cards & Project Cells:**
  - Built with `#181B22` background, 1px border `rgba(146, 148, 157, 0.14)`.
  - Feature subtle hover lift, accentuating hairline borders to `#C8F169` or `#7775F7`.
- **Chips & Badges:**
  - Technical metadata indicators utilizing `label-sm` uppercase.
  - Solid dark backings with a high-contrast dot indicator (`#C8F169` for live/active, `#7775F7` for AI/experimental, `#92949D` for archived).
- **Form Inputs & Search Fields:**
  - Flush surfaces (`#14171E`), hairline border. Focused state replaces border with `#7775F7` with zero offset and creates a subtle inner glow. Text in `#F5F4EF`, placeholder in `#92949D`.
- **Checkboxes & Radios:**
  - Custom square selectors (4px radius). Unchecked: hairline border. Checked: filled `#C8F169` with an `#111318` technical check glyph.
- **Terminal & Metric Displays:**
  - Specialized cards for showcasing tech stacks, live AI status, and CS prototypes. Minimal tabular numeric styling, monospace coordinates, and live blinking lime cursor highlights (`#C8F169`).